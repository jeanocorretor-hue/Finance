import { Dashboard } from '@/components/finance/dashboard'
import { FinanceProvider } from '@/lib/finance-store'

export default function Page() {
  return (
    <FinanceProvider>
      <Dashboard />
    </FinanceProvider>
  )
}
