'use client'

import { CardsPanel } from './cards-panel'
import { ExpensesPanel } from './expenses-panel'
import { MonthSwitcher } from './month-switcher'
import { RevenuesPanel } from './revenues-panel'
import { SummaryCards } from './summary-cards'
import { TrendChart } from './trend-chart'

export function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2.5">
            <span
              aria-hidden
              className="flex size-9 items-center justify-center rounded-xl bg-primary font-mono text-lg font-bold text-primary-foreground"
            >
              A
            </span>
            <div className="leading-tight">
              <p className="text-sm font-semibold">Axis Finance</p>
              <p className="text-xs text-muted-foreground">
                Controle financeiro pessoal
              </p>
            </div>
          </div>
          <MonthSwitcher />
        </div>
      </header>

      <main className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 sm:px-6">
        <SummaryCards />

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="flex flex-col gap-4 lg:col-span-2">
            <TrendChart />
            <ExpensesPanel />
          </div>
          <div className="flex flex-col gap-4">
            <RevenuesPanel />
            <CardsPanel />
          </div>
        </div>

        <footer className="pt-2 text-center text-xs text-muted-foreground">
          Dados de demonstração · padrão template + override mensal · valores em BRL
        </footer>
      </main>
    </div>
  )
}
